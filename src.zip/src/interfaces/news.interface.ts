export class NewsInterface {
  author: string;
  title: string;
  description: string;
  urlToImage: string;
  publishedAt: string;
}