import {Injectable} from '@angular/core';
import {LoadingController, Loading, AlertController} from "ionic-angular";
import {Http} from '@angular/http';
import 'rxjs/Rx';
import {NewsInterface} from "../interfaces/news.interface";


@Injectable()
export class DataProvider {
  http: any;
  loader: Loading;
  news: NewsInterface[];
  baseUrl = 'https://newsapi.org/v2/top-headlines?country=us&category=business&apiKey=3f962e0d7d1b415697cc08c2406ec100';

  constructor(http: Http,
              public loadingCtrl: LoadingController,
              private alertCtrl: AlertController) {
    this.http = http;
  }

  private getUrl(): string {
    return this.baseUrl;
  }

  loadData() {
    this.presentLoading('Please wait...');

    const p1 = new Promise((resolve, reject) => {
      this.http.get(this.getUrl())
        .map(res => res.json())
        .timeout(15000)
        .subscribe(
          (response) => {

            this.news = response.articles;
            console.log(this.news);

            resolve('news');
          },
          (err) => {
            reject('error get news');
          });
    });

    Promise.all([p1])
      .then((values) => {
        // console.log('values:', values);
        this.dismissLoading();
      }, reason => {
        console.log(reason);
        //مشكلة في جلب البيانات، الرجاء التأكد من الاتصال بالانترنت
        this.dismissLoading();
        // Display error message for user
        const alert = this.alertCtrl.create({
          title: 'Error',
          subTitle: '',
          message: 'Problem getting data, please insure you are connected to the Internet',
          buttons: ['OK']
        });

        alert.present().then().catch();
      })
      .catch((reason) => {
        //console.log(reason);
        this.dismissLoading();
      });
  }

  presentLoading(text) {

    this.loader = this.loadingCtrl.create({
      content: text,
    });

    this.loader.present().then().catch();

  }

  dismissLoading() {
    this.loader.dismiss().then().catch();
  }

}