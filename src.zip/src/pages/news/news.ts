import { Component } from '@angular/core';
import {IonicPage, ModalController, NavController, NavParams} from 'ionic-angular';
import {DataProvider} from "../../providers/data.provider";
import {NewsInterface} from "../../interfaces/news.interface";

/**
 * Generated class for the NewsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-news',
  templateUrl: 'news.html',
})
export class NewsPage {

  constructor(public navCtrl: NavController,
              public navParams: NavParams,
              public dataProvider: DataProvider,
              public modalCtrl: ModalController) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad NewsPage');
  }

  onShowDetails(news: NewsInterface, index: number) {
    console.log(news);
    let newsDetails = this.modalCtrl.create('DetailsPage', {news: news});
    newsDetails.present().then().catch();
  }

}
